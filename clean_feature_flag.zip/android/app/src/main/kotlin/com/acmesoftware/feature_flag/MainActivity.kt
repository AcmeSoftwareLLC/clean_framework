package com.acmesoftware.feature_flag

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
